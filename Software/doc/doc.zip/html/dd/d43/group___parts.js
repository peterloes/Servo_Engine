var group___parts =
[
    [ "EFM32G230F128", "d9/d34/group___e_f_m32_g230_f128.html", "d9/d34/group___e_f_m32_g230_f128" ]
];