var group___e_f_m32_g230_f128___bit_fields =
[
    [ "EFM32G230F128_DMA Bit Fields", "d0/dd8/group___e_f_m32_g230_f128___d_m_a___bit_fields.html", "d0/dd8/group___e_f_m32_g230_f128___d_m_a___bit_fields" ],
    [ "EFM32G230F128_CMU Bit Fields", "db/d82/group___e_f_m32_g230_f128___c_m_u___bit_fields.html", "db/d82/group___e_f_m32_g230_f128___c_m_u___bit_fields" ],
    [ "EFM32G230F128_PRS Bit Fields", "d7/da6/group___e_f_m32_g230_f128___p_r_s___bit_fields.html", "d7/da6/group___e_f_m32_g230_f128___p_r_s___bit_fields" ],
    [ "EFM32G230F128 Unlock Codes", "d7/df4/group___e_f_m32_g230_f128___u_n_l_o_c_k.html", "d7/df4/group___e_f_m32_g230_f128___u_n_l_o_c_k" ],
    [ "EFM32G230F128_PRS_Signals", "d0/d62/group___e_f_m32_g230_f128___p_r_s___signals.html", "d0/d62/group___e_f_m32_g230_f128___p_r_s___signals" ]
];