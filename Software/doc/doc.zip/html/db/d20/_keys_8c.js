var _keys_8c =
[
    [ "KEY_STATE", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7", [
      [ "KEY_IDLE", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a692901b9e40247863d81b06b01a5327f", null ],
      [ "KEY_S1", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a86a476da631327f3c39857c430863ede", null ],
      [ "KEY_S2", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a6b6687fdaa7f39d6e076fc7b96240a7e", null ],
      [ "KEY_S3", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7aa6fe137261cfa9867262e5db3079df6d", null ],
      [ "KEY_CNT", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7ad844e3d999f31a49106e862970bfd5a8", null ]
    ] ],
    [ "KeyTimerFct", "db/d20/_keys_8c.html#a712afd0aadf82290e704d7f29bfe03fa", null ],
    [ "KeyInit", "db/d20/_keys_8c.html#aead7281356b65fb68529b3baaa263d1b", null ],
    [ "KeyHandler", "db/d20/_keys_8c.html#aa2e9146eb68121ec8c921491eaace740", null ],
    [ "l_pKeyInit", "db/d20/_keys_8c.html#a86a5fe4ac83ab0b9d92942c217f80b98", null ],
    [ "l_KeyState", "db/d20/_keys_8c.html#ae1398fb77cd1f3e6b64beda2dda7db03", null ],
    [ "l_KeyCode", "db/d20/_keys_8c.html#a9e1a4915b87c3a7e4b6aa77da040a0a3", null ]
];