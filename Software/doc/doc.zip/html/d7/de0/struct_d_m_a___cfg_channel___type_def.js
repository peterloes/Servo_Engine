var struct_d_m_a___cfg_channel___type_def =
[
    [ "highPri", "d7/de0/struct_d_m_a___cfg_channel___type_def.html#ae12dbfbdfcc0abe8c197658768b6e767", null ],
    [ "enableInt", "d7/de0/struct_d_m_a___cfg_channel___type_def.html#a7524eb6241d1b2490fce40576fa213f1", null ],
    [ "select", "d7/de0/struct_d_m_a___cfg_channel___type_def.html#a72bbe3d806659a3f4677e74aa3dfdfad", null ],
    [ "cb", "d7/de0/struct_d_m_a___cfg_channel___type_def.html#a4cf0f4425187497028197f2134fa15b3", null ]
];