var struct_clock___init___type_def =
[
    [ "startDate", "db/dfe/struct_clock___init___type_def.html#ab994d94be60162263bd739d9a759859a", null ],
    [ "rtcCountsPerSec", "db/dfe/struct_clock___init___type_def.html#a00ba0777d3877a61357a40ea0812c8f4", null ]
];