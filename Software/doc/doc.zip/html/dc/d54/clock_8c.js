var clock_8c =
[
    [ "time", "dc/d54/clock_8c.html#a26c7d1dbf93fa8c23c5effbacec91f8c", null ],
    [ "clockInit", "dc/d54/clock_8c.html#a90216ec79565726dbb875b164e370e1b", null ],
    [ "clockSetStartCalendar", "dc/d54/clock_8c.html#a05925ead76c924b763c357089ff64a36", null ],
    [ "clockSetStartTime", "dc/d54/clock_8c.html#a4d26ceb4be24eb47b00830875eb9e744", null ],
    [ "clockGetStartTime", "dc/d54/clock_8c.html#a4bad6c2bd6b2eb31d536d260fcd65dc5", null ],
    [ "clockOverflow", "dc/d54/clock_8c.html#a9cc32e2679df7babf577156e973b5872", null ],
    [ "clockSetOverflowCounter", "dc/d54/clock_8c.html#a9401c4d8e2428541dc42db31d65991ab", null ],
    [ "clockGetOverflowCounter", "dc/d54/clock_8c.html#ae7630244bbdcc8b257ccffc30c9c1b5b", null ],
    [ "rtcCountsPerSec", "dc/d54/clock_8c.html#a03490d18114b9c8ac68300eb30964350", null ],
    [ "g_rtcStartTime", "dc/d54/clock_8c.html#aafc9de1c145f8ff56e634db2d0dbd7c9", null ],
    [ "rtcOverflowCounter", "dc/d54/clock_8c.html#a08701abdb086d0ceeef9b37b434a8a4e", null ],
    [ "rtcOverflowInterval", "dc/d54/clock_8c.html#aa47f33c7c543c91be69841657191f9f2", null ],
    [ "rtcOverflowIntervalR", "dc/d54/clock_8c.html#aa36a77c024a732bed517573b9b6b3d50", null ]
];