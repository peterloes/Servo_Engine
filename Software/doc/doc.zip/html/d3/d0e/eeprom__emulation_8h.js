var eeprom__emulation_8h =
[
    [ "EE_Variable_TypeDef", "d6/ddd/struct_e_e___variable___type_def.html", "d6/ddd/struct_e_e___variable___type_def" ],
    [ "EE_Page_TypeDef", "d7/d20/struct_e_e___page___type_def.html", "d7/d20/struct_e_e___page___type_def" ],
    [ "PAGE_SIZE", "d3/d0e/eeprom__emulation_8h.html#a7d467c1d283fdfa1f2081ba1e0d01b6e", null ],
    [ "DEFAULT_NUMBER_OF_PAGES", "d3/d0e/eeprom__emulation_8h.html#ad0a91801380a486f84db06cd2ed26107", null ],
    [ "MAX_NUMBER_OF_PAGES", "d3/d0e/eeprom__emulation_8h.html#a29c72d4a4e7d55a00f381cb35aeccd5f", null ],
    [ "SIZE_OF_DATA", "d3/d0e/eeprom__emulation_8h.html#a458727ba44329288f712b89a0b52199a", null ],
    [ "SIZE_OF_VIRTUAL_ADDRESS", "d3/d0e/eeprom__emulation_8h.html#a67a7ec62c89139687297a61c2b927102", null ],
    [ "SIZE_OF_VARIABLE", "d3/d0e/eeprom__emulation_8h.html#a888bc5a3741db16f364d65dda09ff138", null ],
    [ "MAX_ACTIVE_VARIABLES", "d3/d0e/eeprom__emulation_8h.html#a18dc513f70f31d94003f70f241b040d4", null ],
    [ "PAGE_STATUS_ERASED", "d3/d0e/eeprom__emulation_8h.html#a00937a29a5d1fcb774c6eb9fd93a3fe8", null ],
    [ "PAGE_STATUS_RECEIVING", "d3/d0e/eeprom__emulation_8h.html#aa56ec8489cf1ef2174d76ae25282e1c4", null ],
    [ "PAGE_STATUS_ACTIVE", "d3/d0e/eeprom__emulation_8h.html#a4b5958638512bc418ea6df83413a06e1", null ],
    [ "EE_PageStatus_TypeDef", "d3/d0e/eeprom__emulation_8h.html#a5f610b3374ec73d42be66d804d48e456", [
      [ "eePageStatusErased", "d3/d0e/eeprom__emulation_8h.html#a5f610b3374ec73d42be66d804d48e456a1cb6aba7ab52205c33c6260f5cecfcb2", null ],
      [ "eePageStatusReceiving", "d3/d0e/eeprom__emulation_8h.html#a5f610b3374ec73d42be66d804d48e456a2936a3d21715137ecfd58dba56ecba7f", null ],
      [ "eePageStatusActive", "d3/d0e/eeprom__emulation_8h.html#a5f610b3374ec73d42be66d804d48e456a7fa11407b0ec970c18ec5c620c57adc9", null ]
    ] ],
    [ "EE_Init", "d3/d0e/eeprom__emulation_8h.html#a3b933c558a94f35bf48faede33b3ff07", null ],
    [ "EE_Format", "d3/d0e/eeprom__emulation_8h.html#a06e7f50469d6df0d2ade7c328f8923d3", null ],
    [ "EE_Read", "d3/d0e/eeprom__emulation_8h.html#a082ff37cc62f1d381cc42a01caeecec7", null ],
    [ "EE_Write", "d3/d0e/eeprom__emulation_8h.html#a73ea2ccea258e8d71922a3c98c4eb462", null ],
    [ "EE_DeclareVariable", "d3/d0e/eeprom__emulation_8h.html#a9783c147f3495ba96b8fb89d99ced0b4", null ],
    [ "EE_DeleteVariable", "d3/d0e/eeprom__emulation_8h.html#a9be0ec76d40c57a34fd6058fc37948cd", null ],
    [ "EE_GetEraseCount", "d3/d0e/eeprom__emulation_8h.html#a11852f9fdcfeca289df3928c5b9ddd1c", null ],
    [ "EE_getPageStatus", "d3/d0e/eeprom__emulation_8h.html#a52fd3ec2582ac832a845fce67d7ab8ee", null ],
    [ "EE_setPageStatusActive", "d3/d0e/eeprom__emulation_8h.html#a8346e11b3dc554ebbf7544d454568af0", null ],
    [ "EE_setPageStatusReceiving", "d3/d0e/eeprom__emulation_8h.html#a840036e54a696f5c5599633f00bbe388", null ],
    [ "pageStatusActiveValue", "d3/d0e/eeprom__emulation_8h.html#a80910fe6001b6fb57a48d312fbb33ceb", null ],
    [ "pageStatusReceivingValue", "d3/d0e/eeprom__emulation_8h.html#a8534420b01b71dc8b4f7ce2bb37436eb", null ]
];