var em__common_8h =
[
    [ "EFM32_MIN", "d6/d46/em__common_8h.html#ga4697e43b9f1da10aced32da568a8c729", null ],
    [ "EFM32_MAX", "d6/d46/em__common_8h.html#ga939df829c7cdcf8a52a80b5dc121e75a", null ],
    [ "EFM32_PACK_START", "d6/d46/em__common_8h.html#ga099d98fa4e24657df90ae06fc13a4815", null ],
    [ "EFM32_PACK_END", "d6/d46/em__common_8h.html#gab2675861d42aae2af68c05f8fa1da22f", null ],
    [ "EFM32_ALIGN", "d6/d46/em__common_8h.html#ga3e1e293640dd826cbd20924b763ddcc0", null ]
];