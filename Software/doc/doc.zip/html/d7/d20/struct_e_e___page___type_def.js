var struct_e_e___page___type_def =
[
    [ "startAddress", "d7/d20/struct_e_e___page___type_def.html#addf1a265e1837796021f4e7a225dc591", null ],
    [ "endAddress", "d7/d20/struct_e_e___page___type_def.html#aa83e530107c35541dee075f76127c042", null ]
];