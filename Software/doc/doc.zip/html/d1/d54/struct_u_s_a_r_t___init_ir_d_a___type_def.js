var struct_u_s_a_r_t___init_ir_d_a___type_def =
[
    [ "async", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#a3c3750a9ff2e1d251e123e170ef28873", null ],
    [ "irRxInv", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#a159f253436cc308c46e2c4e7fb22d1eb", null ],
    [ "irFilt", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#aed5f507d0abdbdfd06cb0a01ae61254d", null ],
    [ "irPw", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#a5f060c2b03911d2a6eb36b305b941200", null ],
    [ "irPrsEn", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#a4962113509936d579de6a3793b7f0ef6", null ],
    [ "irPrsSel", "d1/d54/struct_u_s_a_r_t___init_ir_d_a___type_def.html#ac444d7b44db1d1a62532fe9a54434964", null ]
];